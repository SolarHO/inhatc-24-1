from tensorflow.keras.models import load_model
import json
import cv2
import numpy as np
from tensorflow.keras.preprocessing.image import img_to_array

model = load_model('gender_classification_cnn1.h5')

def preprocess_image(image_path, json_path, target_size=(200, 200)):
    try:
        image = cv2.imread(image_path)
        if image is None:
            print(f"Failed to load image: {image_path}")
            return None

        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        box = data['annotation']['box']
        x, y, w, h = int(box['x']), int(box['y']), int(box['w']), int(box['h'])
        img_height, img_width = image.shape[:2]
        x = max(0, min(x, img_width - 1))
        y = max(0, min(y, img_height - 1))
        w = max(1, min(w, img_width - x))
        h = max(1, min(h, img_height - y))
        
        face = image[y:y+h, x:x+w]
        face = cv2.resize(face, target_size)
        face = img_to_array(face) / 255.0
        face = np.expand_dims(face, axis=0)

        return face
    except Exception as e:
        print(f"{image_path}, {e}")
        return None

# 테스트
test_image_path = 'C:/Users/cczzs/Downloads/Sample/01.OriginalData/0035/0035_direct_indoor_acc_00000000.png'
test_json_path = 'C:/Users/cczzs/Downloads/Sample/02.LabelingData/106point/0035/0035_direct_indoor_acc_00000000.json'

# 이미지 전처리
preprocessed_image = preprocess_image(test_image_path, test_json_path)

if preprocessed_image is not None:
    # 모델 예측
    prediction = model.predict(preprocessed_image)
    class_idx = np.argmax(prediction, axis=1)[0]
    confidence = prediction[0][class_idx]

    # 예측 결과 해석
    if class_idx == 1:
        print(f"'여자', 퍼센트 {confidence * 100:.2f}%")
    else:
        print(f"'남자', 퍼센트 {confidence * 100:.2f}%")
else:
    print("실패")
