import os
import json
import cv2
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout,BatchNormalization, Activation
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.preprocessing.image import img_to_array
from tensorflow.keras.utils import to_categorical
from sklearn.model_selection import train_test_split

def load_data(root_folder, target_size=(200, 200)):
    images = []
    labels = []
    
    image_folder = os.path.join(root_folder, '01.OriginalData')
    json_folder = os.path.join(root_folder, '02.LabelingData/106point')
    
    for subfolder in os.listdir(image_folder):
        image_subfolder_path = os.path.join(image_folder, subfolder)
        json_subfolder_path = os.path.join(json_folder, subfolder)
        
        if os.path.isdir(image_subfolder_path) and os.path.isdir(json_subfolder_path):
            print(f"Processing folder: {subfolder}")
            
            for image_file in os.listdir(image_subfolder_path):
                if image_file.endswith('.png'):
                    image_path = os.path.join(image_subfolder_path, image_file)

                    try:
                        image = cv2.imread(image_path)
                        if image is None:
                            print(f"Failed to load image: {image_path}")
                            continue
                        
                        json_file_name = image_file.replace('.png', '.json')
                        json_path = os.path.join(json_subfolder_path, json_file_name)
                        
                        if os.path.exists(json_path):
                            with open(json_path, 'r', encoding='utf-8') as f:
                                data = json.load(f)
                            
                            box = data['annotation']['box']
                            x, y, w, h = int(box['x']), int(box['y']), int(box['w']), int(box['h'])
                            img_height, img_width = image.shape[:2]
                            x = max(0, min(x, img_width - 1))
                            y = max(0, min(y, img_height - 1))
                            w = max(1, min(w, img_width - x))
                            h = max(1, min(h, img_height - y))
                            
                            face = image[y:y+h, x:x+w]
                            
                            if face.size == 0:
                                print(f"Empty face image: {image_file}")
                                continue
                            
                            face = cv2.resize(face, target_size)
                            face = img_to_array(face) / 255.0
                            
                            images.append(face)
                            
                            label = 1 if data['gender'] == 'female' else 0
                            labels.append(label)
                        else:
                            print(f"{image_file},폴더 {subfolder}")
                    except Exception as e:
                        print(f"{image_path},{e}")
    
    images = np.array(images, dtype='float32')
    labels = np.array(labels)
    labels = to_categorical(labels, num_classes=2)   
    return images, labels

root_folder = 'C:/Users/cczzs/Downloads/Sample'
X, y = load_data(root_folder)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = Sequential([
    Conv2D(36, kernel_size=3,input_shape=(200,200,3)),
    BatchNormalization(),
    Activation('relu'),
    MaxPooling2D(pool_size=3, strides=2),
    Conv2D(64, kernel_size=3),
    BatchNormalization(),
    Activation('relu'),
    MaxPooling2D(pool_size=3, strides=2),
    Conv2D(128, kernel_size=3),
    BatchNormalization(),
    Activation('relu'),
    MaxPooling2D(pool_size=3, strides=2),
    Conv2D(256, kernel_size=3),
    BatchNormalization(),
    Activation('relu'),
    MaxPooling2D(pool_size=3, strides=2),
    Conv2D(512, kernel_size=3),
    BatchNormalization(),
    Activation('relu'),
    MaxPooling2D(pool_size=3, strides=2),
    Flatten(),
    Dropout(0.25),
    Dense(512, activation  = 'relu'),
    Dropout(0.5),
    Dense(2, activation = 'softmax', name = 'gender')
])

# 모델 컴파일
model.compile(optimizer=Adam(learning_rate=0.001),
              loss='categorical_crossentropy',
              metrics=['accuracy'])

# 모델 학습
history = model.fit(
    X_train, y_train,
    validation_data=(X_test, y_test),
    epochs=20,
    batch_size=32
)

# 모델 저장
model.save('gender_classification_cnn2.h5')

# 모델 평가
loss, accuracy = model.evaluate(X_test, y_test)
print(f'loss: {loss}')
print(f'accuracy: {accuracy}')
